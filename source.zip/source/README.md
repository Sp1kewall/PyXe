_____________________________________
ENG
_____________________________________

Space Terminal
Just my terminal

Training:
To update modules, press Ctrl+ C 
To get a list of all commands, write the command HELP or help

Innovations:
Now there are detailed instructions for each command, just write the "help" command and specify "--{command name}"
In the "say" command, you can specify mathematical problems in the argument (for example: 3*4; 5/1*9)


===============================
Version as of 19/02/2023 is 1.6
_____________________________________
RUS
_____________________________________

Space Terminal
Просто мой терминал

Обучение:
Для обновления модулей, нажмите Ctrl + C                                                           
Чтобы получить список всех команд напишите команду HELP или help

Нововведения:
Теперь к каждой команде есть подробнач инструкция, просто напишите команду "help" и в аргументе укажите "--{имя команды}"
В команде "say" можно в аргументе указывать математические задачи (например: 3*4; 5/1*9)


===============================
Версия на 19/02/2023 - 1.6
